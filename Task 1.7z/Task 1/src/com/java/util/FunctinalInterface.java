package com.java.util;


@FunctionalInterface  
interface sayable{  
    void say(String msg);  
}  
public class FunctinalInterface implements sayable{  
    public void say(String msg){  
        System.out.println(msg);  
    }  
    public static void main(String[] args) {  
        FunctinalInterface fie = new FunctinalInterface();  
        fie.say("Hello there");  
    }  
}  
