package com.java.util;

import java.util.function.Consumer;

public class FunctionalInterface2 {
 public static void main(String[] args) {
  Consumer<Integer> multiplier = num -> System.out.println(num*num);
  multiplier.accept(10);//void accept(T t);(abstractmethod)
  multiplier.accept(4);
 }
}