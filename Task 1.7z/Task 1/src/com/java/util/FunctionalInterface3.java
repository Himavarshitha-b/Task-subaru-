package com.java.util;

import java.util.Random;
import java.util.function.Supplier;


public class FunctionalInterface3 {
 public static void main(String[] args) {
  Supplier<Double> randomNumberSupplier = () -> new Random(10).nextDouble();
  System.out.println(randomNumberSupplier.get());
  System.out.println(randomNumberSupplier.get());
 }
}