package com.java.util;

import java.time.LocalDate;
import java.util.Date;
import java.util.function.Function;

public class Localdate {
	public static void main(String args[]) {
		Function<LocalDate,Integer>yearRetriever=Date->Date.getYear();
		LocalDate today=LocalDate.now();
		System.out.println("Year corresponding to "+today+" is "+yearRetriever.apply(today));
	 }
	

	}
	
