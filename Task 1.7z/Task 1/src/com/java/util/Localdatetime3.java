package com.java.util;

import java.time.LocalDate;

public class Localdatetime3 {
	public static void main(String args[])
	{
		LocalDate date1=LocalDate .of(2020, 2, 10);
		System.out.println(date1.isLeapYear());
		LocalDate date2=LocalDate .of(2019, 3, 1);
		System.out.println(date2.isLeapYear());
		
	}

}
