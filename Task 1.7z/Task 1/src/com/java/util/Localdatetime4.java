package com.java.util;

import java.time.LocalDate;

public class Localdatetime4 {
	public static void main (String args[]) {
		
	 LocalDate date = LocalDate.of(2017, 1, 13);  
	    java.time.LocalDateTime localdatetime = date.atTime(1,50,9);      
	    System.out.println(localdatetime);   
	  }  
	}  

	
