package com.java.util;


interface addition{  
    void add();  
}  
public class Methodreference3 {  
    public static void addSomething(){  
        System.out.println("Hello, this is static method.");  
    }  
    public static void main(String[] args) {  
        // Referring static method  
        addition addition = Methodreference3::addSomething;  
        // Calling interface method  
        addition.add();  
    }  
}  