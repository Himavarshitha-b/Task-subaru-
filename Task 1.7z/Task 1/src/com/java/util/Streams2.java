package com.java.util;

import java.util.Arrays;
import java.util.IntSummaryStatistics;
import java.util.List;

public class Streams2 {
	public static void main(String args[])
	{
		List<Integer> primes=Arrays.asList(2,3,5,7,11,13,17);
				             
				IntSummaryStatistics stats = primes.stream() .mapToInt((x) -> x) .summaryStatistics();
				System.out.println("highestprimenumber:"+stats.getMax());
				System.out.println("lowestprimenumber:"+stats.getMin());
				System.out.println("Sum of all prime numbers:"+stats.getSum());
				System.out.println("average of all prime numbers:"+stats.getAverage());

	}

}
