package com.java.util;

import java.awt.Graphics;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;

public class TextPrinter implements Printable{
 public void print(String str) {
  System.out.println("Printing "+str);
}
 
 public static void main(String[] args) {
  TextPrinter textPrinter = new TextPrinter();
  textPrinter.print("Hello");
 }

@Override
public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) throws PrinterException {
	// TODO Auto-generated method stub
	return 0;
}
}