package com.java.util;

interface message{  
    // Default method   
    default void msg(){  
        System.out.println(" this is default method");  
    }  
    // Abstract method  
    void msgMore(String msg);  
}  
public class defaltIntereface implements message{  
    public void sayMore(String msg){        // implementing abstract method   
        System.out.println(msg);  
    }  
    public static void main(String[] args) {  
        defaltIntereface dm = new defaltIntereface();  
        dm.msg();   // calling default method  
        dm.msgMore("Work is worship");  // calling abstract method  
  
    }
	@Override
	public void msgMore(String msg) {
		// TODO Auto-generated method stub
		
	}  
}  