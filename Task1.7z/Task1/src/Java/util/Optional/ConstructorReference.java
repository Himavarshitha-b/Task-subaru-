package Java.util.Optional;

interface Message1
{
	Message getMessage(String msg);


	
}
class Message{  
    Message(String msg){  
        System.out.print(msg);  
    }  
}  
public class ConstructorReference {
	public static void main(String arga[]) {
		Message1 capgemini=Message ::new; 
        capgemini.getMessage("Capgemini");  
	}

}
