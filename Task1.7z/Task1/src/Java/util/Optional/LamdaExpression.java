package Java.util.Optional;

@FunctionalInterface
interface Lambda {

	public void draw();

}

public class LamdaExpression {
	public static void main(String args[]) {
		int Len = 30;
		int Breadth=20;

		Lambda  d2 = () -> {System.out.println("double"+Len);
		int z=Len*Breadth;
		System.out.println("double"+Breadth);
		System.out.println(z);
		};
		d2.draw();
		

	
	}
}
