package Java.util.Optional;

interface addition {

	void main(int x, int y);

}

public  class Sum implements addition

{
	public void main(int x, int y) {
		System.out.println("int x ,int y "+""+(x+y));
	}

	public static void main(String args[]) {
		Sum sum = new Sum();
		sum.main(10, 20);

	}
}
