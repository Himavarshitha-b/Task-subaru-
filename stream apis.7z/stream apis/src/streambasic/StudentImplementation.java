package streambasic;

import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class StudentImplementation{
	
	
	public static Student highestPercentage(List<Student>list) {
	      Student count=list
	    		  .stream()
	    		  .max((p1,p2)->(int)(p1.getPercent()-p2.getPercent()))
	    		  .get();
	      return count; 
	  }
	
	public static List<Student> percentage80(List<Student>list) {
		List<Student> hi80= list
				  .stream()
				  .filter(c -> c.getPercent()>=80 )
				  .collect(Collectors.toList());
		return hi80;
	  }
	
	public static long percentage90(List<Student>list) {
		long count1 = list
			  .stream()
			  .filter(c -> c.getPercent()>90 )
			  .count();
		return count1;
		
	  }
	
	public static long electriclStudents (List<Student>list) {
		
		long count = list
				  .stream()
				  .filter(c -> c.getBranch().equalsIgnoreCase("electrical engg") )
				  .count();
		return count;
	  }
	
    public static List<Student> startsWithALetter (List<Student>list) {
		
  List<Student> nameStartsWithA = list
		                         .stream()
                                 .filter(student -> student.getName().startsWith("A"))
                                 .collect(Collectors.toList());
	           
	     return nameStartsWithA;
	  }
    
    public static long selectBranch (List<Student>list) {
		
    
		Scanner sc= new Scanner(System.in);
		String branch1 = sc.nextLine();
		  long count = list
				  .stream()
				  .filter(c -> c.getBranch().equalsIgnoreCase(branch1) )
				  .count();
        
      return count;
}
	
}


